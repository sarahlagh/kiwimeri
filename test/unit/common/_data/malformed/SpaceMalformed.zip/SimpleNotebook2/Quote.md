This is a **simple** test with some *basic* style

And malformed ~~~ chars


